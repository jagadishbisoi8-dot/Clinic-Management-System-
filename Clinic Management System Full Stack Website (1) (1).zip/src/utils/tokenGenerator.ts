
import { format } from 'date-fns'

export const generateTokenNumber = async (date: Date = new Date()): Promise<string> => {
  const dateStr = format(date, 'yyyyMMdd')
  const timeStr = Date.now().toString().slice(-4)
  return `T${timeStr}-${dateStr}`
}

export const generatePatientId = (): string => {
  const timestamp = Date.now().toString().slice(-6)
  return `PAT-${timestamp}`
}

export const generatePrescriptionId = (): string => {
  const timestamp = Date.now().toString().slice(-6)
  return `PRES-${timestamp}`
}

export const generateBillId = (): string => {
  const timestamp = Date.now().toString().slice(-6)
  return `BILL-${timestamp}`
}

export const generateStaffId = (role: 'doctor' | 'receptionist'): string => {
  const prefix = role === 'doctor' ? 'DOC' : 'REC'
  const timestamp = Date.now().toString().slice(-3)
  return `${prefix}-${timestamp}`
}

export const calculateBillTotal = (items: Array<{quantity: number, unitPrice: number}>, tax: number = 0, discount: number = 0): number => {
  const subtotal = items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0)
  return subtotal + tax - discount
}
