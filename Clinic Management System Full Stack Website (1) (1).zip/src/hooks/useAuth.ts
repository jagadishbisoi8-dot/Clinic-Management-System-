
import { useState, useEffect } from 'react'
import { lumi } from '../lib/lumi'

export interface AuthUser {
  userId: string
  email: string
  userName: string
  role?: 'doctor' | 'receptionist' | 'admin'
  staffId?: string
}

export const useAuth = () => {
  const [user, setUser] = useState<AuthUser | null>(lumi.auth.user)
  const [isAuthenticated, setIsAuthenticated] = useState(lumi.auth.isAuthenticated)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = lumi.auth.onAuthChange(async ({ isAuthenticated, user }) => {
      setIsAuthenticated(isAuthenticated)
      
      if (isAuthenticated && user) {
        // Check if user is staff member
        try {
          const { list: staffList } = await lumi.entities.staff.list({
            filter: { email: user.email }
          })
          
          if (staffList && staffList.length > 0) {
            const staffMember = staffList[0]
            setUser({
              ...user,
              role: staffMember.role as 'doctor' | 'receptionist' | 'admin',
              staffId: staffMember.staffId
            })
          } else {
            setUser(user)
          }
        } catch (error) {
          console.error('Failed to fetch staff info:', error)
          setUser(user)
        }
      } else {
        setUser(null)
      }
      
      setLoading(false)
    })
    
    setLoading(false)
    return unsubscribe
  }, [])

  const signIn = async () => {
    try {
      const { user } = await lumi.auth.signIn()
      return user
    } catch (error) {
      console.error('Sign in failed:', error)
      throw error
    }
  }

  const signOut = () => {
    lumi.auth.signOut()
  }

  return { user, isAuthenticated, loading, signIn, signOut }
}
