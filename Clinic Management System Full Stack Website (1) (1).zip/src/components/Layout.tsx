
import React from 'react'
import { Link, useLocation, Outlet } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import {Users, Calendar, FileText, CreditCard, UserCheck, LogOut, Hospital, Settings} from 'lucide-react'

const Layout: React.FC = () => {
  const { user, signOut } = useAuth()
  const location = useLocation()

  const doctorMenuItems = [
    { path: '/dashboard', icon: Hospital, label: 'Dashboard' },
    { path: '/patients', icon: Users, label: 'Patients' },
    { path: '/tokens', icon: Calendar, label: 'Appointments' },
    { path: '/prescriptions', icon: FileText, label: 'Prescriptions' },
  ]

  const receptionistMenuItems = [
    { path: '/dashboard', icon: Hospital, label: 'Dashboard' },
    { path: '/patients', icon: Users, label: 'Patients' },
    { path: '/tokens', icon: Calendar, label: 'Token Management' },
    { path: '/bills', icon: CreditCard, label: 'Billing' },
    { path: '/staff', icon: UserCheck, label: 'Staff' },
  ]

  const menuItems = user?.role === 'doctor' ? doctorMenuItems : receptionistMenuItems

  const isActive = (path: string) => location.pathname === path

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <Hospital className="w-8 h-8 text-blue-600" />
            <div>
              <h1 className="text-xl font-bold text-gray-900">ClinicCare</h1>
              <p className="text-sm text-gray-500">Management System</p>
            </div>
          </div>
        </div>

        <nav className="mt-6">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-3 px-6 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors ${
                  isActive(item.path) ? 'bg-blue-50 text-blue-600 border-r-2 border-blue-600' : ''
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            )
          })}
        </nav>

        {/* User Info */}
        <div className="absolute bottom-0 w-64 p-6 border-t border-gray-200">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
              <span className="text-white font-semibold">
                {user?.userName?.charAt(0)?.toUpperCase() || 'U'}
              </span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">{user?.userName}</p>
              <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
            </div>
          </div>
          <button
            onClick={signOut}
            className="flex items-center space-x-2 text-gray-600 hover:text-red-600 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span className="text-sm">Sign Out</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                {menuItems.find(item => isActive(item.path))?.label || 'Dashboard'}
              </h2>
              <p className="text-gray-600">Welcome back, {user?.userName}</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-500">Today</p>
                <p className="text-sm font-medium">{new Date().toLocaleDateString()}</p>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

export default Layout
