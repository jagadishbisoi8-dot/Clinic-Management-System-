
import React, { useState, useEffect } from 'react'
import { lumi } from '../lib/lumi'
import { useAuth } from '../hooks/useAuth'
import {Plus, Search, FileText, User, Calendar, Pill, Clock, Edit, Trash2} from 'lucide-react'
import toast from 'react-hot-toast'
import { generatePrescriptionId } from '../utils/tokenGenerator'

interface Prescription {
  _id: string
  prescriptionId: string
  patientId: string
  patientName: string
  doctorId: string
  doctorName: string
  tokenId?: string
  diagnosis: string
  medications: Medication[]
  instructions: string
  followUpDate?: string
  status: string
  createdAt: string
}

interface Medication {
  name: string
  dosage: string
  frequency: string
  duration: string
  instructions: string
}

interface Patient {
  _id: string
  patientId: string
  name: string
}

interface Token {
  _id: string
  tokenNumber: string
  patientId: string
  patientName: string
  status: string
}

const Prescriptions: React.FC = () => {
  const { user } = useAuth()
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([])
  const [patients, setPatients] = useState<Patient[]>([])
  const [activeTokens, setActiveTokens] = useState<Token[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editingPrescription, setEditingPrescription] = useState<Prescription | null>(null)
  const [medications, setMedications] = useState<Medication[]>([
    { name: '', dosage: '', frequency: '', duration: '', instructions: '' }
  ])

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      
      const [prescriptionsRes, patientsRes, tokensRes] = await Promise.all([
        lumi.entities.prescriptions.list({
          sort: { createdAt: -1 },
          ...(user?.role === 'doctor' ? { filter: { doctorId: user.staffId } } : {})
        }),
        lumi.entities.patients.list({ filter: { status: 'active' } }),
        lumi.entities.tokens.list({ filter: { status: 'in_progress' } })
      ])

      setPrescriptions(prescriptionsRes.list || [])
      setPatients(patientsRes.list || [])
      setActiveTokens(tokensRes.list || [])
    } catch (error) {
      console.error('Failed to fetch data:', error)
      toast.error('Failed to load data')
    } finally {
      setLoading(false)
    }
  }

  const addMedication = () => {
    setMedications([...medications, { name: '', dosage: '', frequency: '', duration: '', instructions: '' }])
  }

  const removeMedication = (index: number) => {
    if (medications.length > 1) {
      setMedications(medications.filter((_, i) => i !== index))
    }
  }

  const updateMedication = (index: number, field: keyof Medication, value: string) => {
    const updatedMedications = [...medications]
    updatedMedications[index] = { ...updatedMedications[index], [field]: value }
    setMedications(updatedMedications)
  }

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    
    const selectedPatient = patients.find(p => p._id === formData.get('patientId'))
    if (!selectedPatient) {
      toast.error('Please select a patient')
      return
    }

    // Filter out empty medications
    const validMedications = medications.filter(med => med.name.trim() !== '')
    if (validMedications.length === 0) {
      toast.error('Please add at least one medication')
      return
    }

    const prescriptionData = {
      prescriptionId: editingPrescription?.prescriptionId || generatePrescriptionId(),
      patientId: selectedPatient._id,
      patientName: selectedPatient.name,
      doctorId: user?.staffId || 'unknown',
      doctorName: user?.userName || 'Unknown Doctor',
      tokenId: formData.get('tokenId') as string || undefined,
      diagnosis: formData.get('diagnosis') as string,
      medications: validMedications,
      instructions: formData.get('instructions') as string,
      followUpDate: formData.get('followUpDate') ? new Date(formData.get('followUpDate') as string).toISOString() : undefined,
      status: 'active',
      creator: user?.staffId || user?.userName || 'system',
      createdAt: editingPrescription?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    try {
      if (editingPrescription) {
        await lumi.entities.prescriptions.update(editingPrescription._id, prescriptionData)
        toast.success('Prescription updated successfully')
      } else {
        await lumi.entities.prescriptions.create(prescriptionData)
        toast.success('Prescription created successfully')
      }
      
      setShowForm(false)
      setEditingPrescription(null)
      resetForm()
      fetchData()
    } catch (error) {
      console.error('Failed to save prescription:', error)
      toast.error('Failed to save prescription')
    }
  }

  const resetForm = () => {
    setMedications([{ name: '', dosage: '', frequency: '', duration: '', instructions: '' }])
  }

  const handleEdit = (prescription: Prescription) => {
    setEditingPrescription(prescription)
    setMedications(prescription.medications.length > 0 ? prescription.medications : [{ name: '', dosage: '', frequency: '', duration: '', instructions: '' }])
    setShowForm(true)
  }

  const handleDelete = async (prescriptionId: string, patientName: string) => {
    if (!confirm(`Are you sure you want to delete prescription for ${patientName}?`)) return

    try {
      await lumi.entities.prescriptions.delete(prescriptionId)
      toast.success('Prescription deleted successfully')
      fetchData()
    } catch (error) {
      console.error('Failed to delete prescription:', error)
      toast.error('Failed to delete prescription')
    }
  }

  const filteredPrescriptions = prescriptions.filter(prescription =>
    prescription.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    prescription.prescriptionId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    prescription.diagnosis.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Prescriptions</h1>
        {user?.role === 'doctor' && (
          <button
            onClick={() => { setEditingPrescription(null); resetForm(); setShowForm(true) }}
            className="clinic-button-primary flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>New Prescription</span>
          </button>
        )}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Search by patient name, prescription ID, or diagnosis..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="clinic-input pl-10"
        />
      </div>

      {/* Prescriptions List */}
      <div className="space-y-4">
        {filteredPrescriptions.map((prescription) => (
          <div key={prescription._id} className="clinic-card">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <FileText className="w-6 h-6 text-green-600" />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="font-semibold text-gray-900">{prescription.patientName}</h3>
                    <span className="text-sm text-gray-500">{prescription.prescriptionId}</span>
                    <span className={`status-${prescription.status}`}>
                      {prescription.status}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">
                        <strong>Diagnosis:</strong> {prescription.diagnosis}
                      </p>
                      <p className="text-sm text-gray-600">
                        <strong>Doctor:</strong> {prescription.doctorName}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">
                        <strong>Date:</strong> {new Date(prescription.createdAt).toLocaleDateString()}
                      </p>
                      {prescription.followUpDate && (
                        <p className="text-sm text-gray-600">
                          <strong>Follow-up:</strong> {new Date(prescription.followUpDate).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Medications */}
                  <div className="mb-4">
                    <h4 className="font-medium text-gray-900 mb-2">Medications:</h4>
                    <div className="space-y-2">
                      {prescription.medications.map((med, index) => (
                        <div key={index} className="bg-gray-50 p-3 rounded-lg">
                          <div className="flex items-center space-x-2 mb-1">
                            <Pill className="w-4 h-4 text-blue-600" />
                            <span className="font-medium">{med.name}</span>
                            <span className="text-sm text-gray-600">({med.dosage})</span>
                          </div>
                          <p className="text-sm text-gray-600 ml-6">
                            {med.frequency} for {med.duration}
                            {med.instructions && ` - ${med.instructions}`}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {prescription.instructions && (
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <p className="text-sm text-blue-900">
                        <strong>Instructions:</strong> {prescription.instructions}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {user?.role === 'doctor' && (
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleEdit(prescription)}
                    className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(prescription._id, prescription.patientName)}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {filteredPrescriptions.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No prescriptions found</p>
        </div>
      )}

      {/* Prescription Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-6">
                {editingPrescription ? 'Edit Prescription' : 'New Prescription'}
              </h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Patient *
                    </label>
                    <select 
                      name="patientId" 
                      required 
                      defaultValue={editingPrescription?.patientId || ''}
                      className="clinic-select"
                    >
                      <option value="">Select Patient</option>
                      {patients.map((patient) => (
                        <option key={patient._id} value={patient._id}>
                          {patient.name} - {patient.patientId}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Associated Token (Optional)
                    </label>
                    <select 
                      name="tokenId" 
                      defaultValue={editingPrescription?.tokenId || ''}
                      className="clinic-select"
                    >
                      <option value="">No associated token</option>
                      {activeTokens.map((token) => (
                        <option key={token._id} value={token._id}>
                          {token.tokenNumber} - {token.patientName}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Diagnosis *
                  </label>
                  <input
                    name="diagnosis"
                    type="text"
                    required
                    defaultValue={editingPrescription?.diagnosis || ''}
                    className="clinic-input"
                    placeholder="Enter diagnosis"
                  />
                </div>

                {/* Medications */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="block text-sm font-medium text-gray-700">
                      Medications *
                    </label>
                    <button
                      type="button"
                      onClick={addMedication}
                      className="clinic-button-secondary text-sm px-3 py-1"
                    >
                      Add Medication
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    {medications.map((medication, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-medium text-gray-900">Medication {index + 1}</h4>
                          {medications.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeMedication(index)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-sm text-gray-600 mb-1">Medicine Name</label>
                            <input
                              type="text"
                              value={medication.name}
                              onChange={(e) => updateMedication(index, 'name', e.target.value)}
                              className="clinic-input"
                              placeholder="e.g., Paracetamol"
                            />
                          </div>
                          <div>
                            <label className="block text-sm text-gray-600 mb-1">Dosage</label>
                            <input
                              type="text"
                              value={medication.dosage}
                              onChange={(e) => updateMedication(index, 'dosage', e.target.value)}
                              className="clinic-input"
                              placeholder="e.g., 500mg"
                            />
                          </div>
                          <div>
                            <label className="block text-sm text-gray-600 mb-1">Frequency</label>
                            <input
                              type="text"
                              value={medication.frequency}
                              onChange={(e) => updateMedication(index, 'frequency', e.target.value)}
                              className="clinic-input"
                              placeholder="e.g., Twice daily"
                            />
                          </div>
                          <div>
                            <label className="block text-sm text-gray-600 mb-1">Duration</label>
                            <input
                              type="text"
                              value={medication.duration}
                              onChange={(e) => updateMedication(index, 'duration', e.target.value)}
                              className="clinic-input"
                              placeholder="e.g., 7 days"
                            />
                          </div>
                        </div>
                        <div className="mt-3">
                          <label className="block text-sm text-gray-600 mb-1">Instructions</label>
                          <input
                            type="text"
                            value={medication.instructions}
                            onChange={(e) => updateMedication(index, 'instructions', e.target.value)}
                            className="clinic-input"
                            placeholder="e.g., Take after meals"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    General Instructions
                  </label>
                  <textarea
                    name="instructions"
                    defaultValue={editingPrescription?.instructions || ''}
                    className="clinic-textarea"
                    placeholder="General instructions for the patient..."
                    rows={3}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Follow-up Date (Optional)
                  </label>
                  <input
                    name="followUpDate"
                    type="date"
                    defaultValue={editingPrescription?.followUpDate ? new Date(editingPrescription.followUpDate).toISOString().split('T')[0] : ''}
                    className="clinic-input"
                  />
                </div>

                <div className="flex space-x-4 pt-4">
                  <button type="submit" className="clinic-button-primary flex-1">
                    {editingPrescription ? 'Update Prescription' : 'Create Prescription'}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setShowForm(false); setEditingPrescription(null); resetForm() }}
                    className="clinic-button-secondary flex-1"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Prescriptions
