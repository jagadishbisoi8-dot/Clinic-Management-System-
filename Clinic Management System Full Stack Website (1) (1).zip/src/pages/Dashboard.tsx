
import React, { useState, useEffect } from 'react'
import { useAuth } from '../hooks/useAuth'
import { lumi } from '../lib/lumi'
import {Users, Calendar, FileText, CreditCard, TrendingUp, Clock, CheckCircle, AlertCircle} from 'lucide-react'

interface DashboardStats {
  totalPatients: number
  todayTokens: number
  pendingBills: number
  activePrescriptions: number
  waitingPatients: number
  completedToday: number
}

const Dashboard: React.FC = () => {
  const { user } = useAuth()
  const [stats, setStats] = useState<DashboardStats>({
    totalPatients: 0,
    todayTokens: 0,
    pendingBills: 0,
    activePrescriptions: 0,
    waitingPatients: 0,
    completedToday: 0
  })
  const [recentTokens, setRecentTokens] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      
      // Get today's date for filtering
      const today = new Date()
      const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate())
      const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000)

      // Fetch statistics
      const [patientsRes, tokensRes, billsRes, prescriptionsRes] = await Promise.all([
        lumi.entities.patients.list({ filter: { status: 'active' } }),
        lumi.entities.tokens.list({
          filter: {
            date: {
              $gte: todayStart.toISOString(),
              $lt: todayEnd.toISOString()
            }
          }
        }),
        lumi.entities.bills.list({ filter: { paymentStatus: 'pending' } }),
        lumi.entities.prescriptions.list({ filter: { status: 'active' } })
      ])

      const todayTokensList = tokensRes.list || []
      
      setStats({
        totalPatients: patientsRes.list?.length || 0,
        todayTokens: todayTokensList.length,
        pendingBills: billsRes.list?.length || 0,
        activePrescriptions: prescriptionsRes.list?.length || 0,
        waitingPatients: todayTokensList.filter(t => t.status === 'waiting').length,
        completedToday: todayTokensList.filter(t => t.status === 'completed').length
      })

      // Get recent tokens for activity feed
      const recentTokensRes = await lumi.entities.tokens.list({
        sort: { createdAt: -1 },
        limit: 5
      })
      setRecentTokens(recentTokensRes.list || [])

    } catch (error) {
      console.error('Failed to fetch dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const doctorStats = [
    {
      title: 'Today\'s Appointments',
      value: stats.todayTokens,
      icon: Calendar,
      color: 'blue',
      change: '+12%'
    },
    {
      title: 'Waiting Patients',
      value: stats.waitingPatients,
      icon: Clock,
      color: 'yellow',
      change: '-5%'
    },
    {
      title: 'Completed Today',
      value: stats.completedToday,
      icon: CheckCircle,
      color: 'green',
      change: '+8%'
    },
    {
      title: 'Active Prescriptions',
      value: stats.activePrescriptions,
      icon: FileText,
      color: 'purple',
      change: '+3%'
    }
  ]

  const receptionistStats = [
    {
      title: 'Total Patients',
      value: stats.totalPatients,
      icon: Users,
      color: 'blue',
      change: '+15%'
    },
    {
      title: 'Today\'s Tokens',
      value: stats.todayTokens,
      icon: Calendar,
      color: 'green',
      change: '+12%'
    },
    {
      title: 'Pending Bills',
      value: stats.pendingBills,
      icon: CreditCard,
      color: 'red',
      change: '-8%'
    },
    {
      title: 'Revenue Today',
      value: '$2,450',
      icon: TrendingUp,
      color: 'green',
      change: '+22%'
    }
  ]

  const statsToShow = user?.role === 'doctor' ? doctorStats : receptionistStats

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'waiting': return 'text-yellow-600 bg-yellow-100'
      case 'in_progress': return 'text-blue-600 bg-blue-100'
      case 'completed': return 'text-green-600 bg-green-100'
      case 'cancelled': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl text-white p-6">
        <h1 className="text-2xl font-bold mb-2">
          Welcome back, {user?.userName}!
        </h1>
        <p className="text-blue-100">
          {user?.role === 'doctor' 
            ? 'Ready to provide excellent patient care today.' 
            : 'Let\'s manage the clinic operations efficiently.'}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsToShow.map((stat, index) => {
          const Icon = stat.icon
          return (
            <div key={index} className="clinic-card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className={`text-xs mt-1 ${
                    stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {stat.change} from yesterday
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${stat.color}-100`}>
                  <Icon className={`w-6 h-6 text-${stat.color}-600`} />
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <div className="clinic-card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Appointments</h3>
          <div className="space-y-3">
            {recentTokens.length > 0 ? (
              recentTokens.map((token) => (
                <div key={token._id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-semibold text-sm">
                        {token.tokenNumber?.slice(-2)}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{token.patientName}</p>
                      <p className="text-sm text-gray-600">{token.department}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(token.status)}`}>
                      {token.status.replace('_', ' ')}
                    </span>
                    <p className="text-xs text-gray-500 mt-1">{token.timeSlot}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-4">No recent appointments</p>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="clinic-card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            {user?.role === 'doctor' ? (
              <>
                <button className="p-4 bg-blue-50 rounded-lg text-left hover:bg-blue-100 transition-colors">
                  <Users className="w-6 h-6 text-blue-600 mb-2" />
                  <p className="font-medium text-blue-900">View Patients</p>
                  <p className="text-xs text-blue-700">Manage patient records</p>
                </button>
                <button className="p-4 bg-green-50 rounded-lg text-left hover:bg-green-100 transition-colors">
                  <FileText className="w-6 h-6 text-green-600 mb-2" />
                  <p className="font-medium text-green-900">Prescriptions</p>
                  <p className="text-xs text-green-700">Create new prescription</p>
                </button>
                <button className="p-4 bg-purple-50 rounded-lg text-left hover:bg-purple-100 transition-colors">
                  <Calendar className="w-6 h-6 text-purple-600 mb-2" />
                  <p className="font-medium text-purple-900">Appointments</p>
                  <p className="text-xs text-purple-700">View today's schedule</p>
                </button>
                <button className="p-4 bg-yellow-50 rounded-lg text-left hover:bg-yellow-100 transition-colors">
                  <AlertCircle className="w-6 h-6 text-yellow-600 mb-2" />
                  <p className="font-medium text-yellow-900">Urgent Cases</p>
                  <p className="text-xs text-yellow-700">Priority patients</p>
                </button>
              </>
            ) : (
              <>
                <button className="p-4 bg-blue-50 rounded-lg text-left hover:bg-blue-100 transition-colors">
                  <Calendar className="w-6 h-6 text-blue-600 mb-2" />
                  <p className="font-medium text-blue-900">New Token</p>
                  <p className="text-xs text-blue-700">Generate patient token</p>
                </button>
                <button className="p-4 bg-green-50 rounded-lg text-left hover:bg-green-100 transition-colors">
                  <Users className="w-6 h-6 text-green-600 mb-2" />
                  <p className="font-medium text-green-900">Add Patient</p>
                  <p className="text-xs text-green-700">Register new patient</p>
                </button>
                <button className="p-4 bg-purple-50 rounded-lg text-left hover:bg-purple-100 transition-colors">
                  <CreditCard className="w-6 h-6 text-purple-600 mb-2" />
                  <p className="font-medium text-purple-900">Billing</p>
                  <p className="text-xs text-purple-700">Process payments</p>
                </button>
                <button className="p-4 bg-yellow-50 rounded-lg text-left hover:bg-yellow-100 transition-colors">
                  <TrendingUp className="w-6 h-6 text-yellow-600 mb-2" />
                  <p className="font-medium text-yellow-900">Reports</p>
                  <p className="text-xs text-yellow-700">View analytics</p>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
