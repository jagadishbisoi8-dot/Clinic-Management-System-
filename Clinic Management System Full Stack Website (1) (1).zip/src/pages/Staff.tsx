
import React, { useState, useEffect } from 'react'
import { lumi } from '../lib/lumi'
import { useAuth } from '../hooks/useAuth'
import {Plus, Search, UserCheck, Stethoscope, Users, Mail, Phone, Calendar, Edit, Trash2, Award} from 'lucide-react'
import toast from 'react-hot-toast'
import { generateStaffId } from '../utils/tokenGenerator'

interface StaffMember {
  _id: string
  staffId: string
  name: string
  role: string
  email: string
  phone: string
  specialization?: string
  department: string
  qualification: string
  experience: number
  schedule?: any
  status: string
  joinDate: string
  createdAt: string
}

const Staff: React.FC = () => {
  const { user } = useAuth()
  const [staff, setStaff] = useState<StaffMember[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null)
  const [filterRole, setFilterRole] = useState<string>('all')

  useEffect(() => {
    fetchStaff()
  }, [])

  const fetchStaff = async () => {
    try {
      setLoading(true)
      const { list } = await lumi.entities.staff.list({
        sort: { createdAt: -1 }
      })
      setStaff(list || [])
    } catch (error) {
      console.error('Failed to fetch staff:', error)
      toast.error('Failed to load staff')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    
    const role = formData.get('role') as 'doctor' | 'receptionist'
    
    const staffData = {
      staffId: editingStaff?.staffId || generateStaffId(role),
      name: formData.get('name') as string,
      role,
      email: formData.get('email') as string,
      phone: formData.get('phone') as string,
      specialization: formData.get('specialization') as string,
      department: formData.get('department') as string,
      qualification: formData.get('qualification') as string,
      experience: parseInt(formData.get('experience') as string) || 0,
      schedule: {
        monday: formData.get('monday') as string,
        tuesday: formData.get('tuesday') as string,
        wednesday: formData.get('wednesday') as string,
        thursday: formData.get('thursday') as string,
        friday: formData.get('friday') as string,
        saturday: formData.get('saturday') as string,
        sunday: formData.get('sunday') as string
      },
      status: 'active',
      joinDate: formData.get('joinDate') ? new Date(formData.get('joinDate') as string).toISOString() : new Date().toISOString(),
      creator: user?.userName || 'system',
      createdAt: editingStaff?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    try {
      if (editingStaff) {
        await lumi.entities.staff.update(editingStaff._id, staffData)
        toast.success('Staff member updated successfully')
      } else {
        await lumi.entities.staff.create(staffData)
        toast.success('Staff member added successfully')
      }
      
      setShowForm(false)
      setEditingStaff(null)
      fetchStaff()
    } catch (error) {
      console.error('Failed to save staff member:', error)
      toast.error('Failed to save staff member')
    }
  }

  const handleEdit = (staffMember: StaffMember) => {
    setEditingStaff(staffMember)
    setShowForm(true)
  }

  const handleDelete = async (staffId: string, staffName: string) => {
    if (!confirm(`Are you sure you want to delete ${staffName}?`)) return

    try {
      await lumi.entities.staff.delete(staffId)
      toast.success('Staff member deleted successfully')
      fetchStaff()
    } catch (error) {
      console.error('Failed to delete staff member:', error)
      toast.error('Failed to delete staff member')
    }
  }

  const toggleStatus = async (staffId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active'
    
    try {
      await lumi.entities.staff.update(staffId, {
        status: newStatus,
        updatedAt: new Date().toISOString()
      })
      toast.success(`Staff member ${newStatus === 'active' ? 'activated' : 'deactivated'}`)
      fetchStaff()
    } catch (error) {
      console.error('Failed to update staff status:', error)
      toast.error('Failed to update status')
    }
  }

  const filteredStaff = staff.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.staffId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRole = filterRole === 'all' || member.role === filterRole
    return matchesSearch && matchesRole
  })

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'doctor': return <Stethoscope className="w-5 h-5" />
      case 'receptionist': return <UserCheck className="w-5 h-5" />
      default: return <Users className="w-5 h-5" />
    }
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'doctor': return 'text-blue-600 bg-blue-100'
      case 'receptionist': return 'text-green-600 bg-green-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Staff Management</h1>
        <button
          onClick={() => { setEditingStaff(null); setShowForm(true) }}
          className="clinic-button-primary flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add Staff</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by name, ID, or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="clinic-input pl-10"
          />
        </div>
        <select
          value={filterRole}
          onChange={(e) => setFilterRole(e.target.value)}
          className="clinic-select md:w-48"
        >
          <option value="all">All Roles</option>
          <option value="doctor">Doctors</option>
          <option value="receptionist">Receptionists</option>
        </select>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { 
            label: 'Total Staff', 
            value: staff.length, 
            color: 'blue',
            icon: Users
          },
          { 
            label: 'Doctors', 
            value: staff.filter(s => s.role === 'doctor').length, 
            color: 'blue',
            icon: Stethoscope
          },
          { 
            label: 'Receptionists', 
            value: staff.filter(s => s.role === 'receptionist').length, 
            color: 'green',
            icon: UserCheck
          },
          { 
            label: 'Active Staff', 
            value: staff.filter(s => s.status === 'active').length, 
            color: 'green',
            icon: Users
          }
        ].map((stat, index) => {
          const Icon = stat.icon
          return (
            <div key={index} className="clinic-card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${stat.color}-100`}>
                  <Icon className={`w-6 h-6 text-${stat.color}-600`} />
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Staff Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStaff.map((staffMember) => (
          <div key={staffMember._id} className="clinic-card">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getRoleColor(staffMember.role)}`}>
                  {getRoleIcon(staffMember.role)}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{staffMember.name}</h3>
                  <p className="text-sm text-gray-600">{staffMember.staffId}</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleEdit(staffMember)}
                  className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(staffMember._id, staffMember.name)}
                  className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-2 text-sm mb-4">
              <div className="flex items-center justify-between">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRoleColor(staffMember.role)}`}>
                  {staffMember.role}
                </span>
                <span className={`status-${staffMember.status}`}>
                  {staffMember.status}
                </span>
              </div>
              
              <div className="flex items-center space-x-2 text-gray-600">
                <Mail className="w-4 h-4" />
                <span className="truncate">{staffMember.email}</span>
              </div>
              
              <div className="flex items-center space-x-2 text-gray-600">
                <Phone className="w-4 h-4" />
                <span>{staffMember.phone}</span>
              </div>
              
              <div className="flex items-center space-x-2 text-gray-600">
                <Award className="w-4 h-4" />
                <span>{staffMember.qualification}</span>
              </div>
              
              {staffMember.specialization && (
                <div className="flex items-center space-x-2 text-gray-600">
                  <Stethoscope className="w-4 h-4" />
                  <span>{staffMember.specialization}</span>
                </div>
              )}
              
              <div className="flex items-center space-x-2 text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>{staffMember.experience} years experience</span>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <button
                onClick={() => toggleStatus(staffMember._id, staffMember.status)}
                className={`w-full text-sm font-medium py-2 px-4 rounded-lg transition-colors ${
                  staffMember.status === 'active' 
                    ? 'bg-red-100 text-red-700 hover:bg-red-200' 
                    : 'bg-green-100 text-green-700 hover:bg-green-200'
                }`}
              >
                {staffMember.status === 'active' ? 'Deactivate' : 'Activate'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredStaff.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No staff members found</p>
        </div>
      )}

      {/* Staff Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-6">
                {editingStaff ? 'Edit Staff Member' : 'Add New Staff Member'}
              </h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      name="name"
                      type="text"
                      required
                      defaultValue={editingStaff?.name || ''}
                      className="clinic-input"
                      placeholder="Enter full name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Role *
                    </label>
                    <select
                      name="role"
                      required
                      defaultValue={editingStaff?.role || ''}
                      className="clinic-select"
                    >
                      <option value="">Select Role</option>
                      <option value="doctor">Doctor</option>
                      <option value="receptionist">Receptionist</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email *
                    </label>
                    <input
                      name="email"
                      type="email"
                      required
                      defaultValue={editingStaff?.email || ''}
                      className="clinic-input"
                      placeholder="staff@clinic.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number *
                    </label>
                    <input
                      name="phone"
                      type="tel"
                      required
                      defaultValue={editingStaff?.phone || ''}
                      className="clinic-input"
                      placeholder="+1-555-0123"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Specialization
                    </label>
                    <input
                      name="specialization"
                      type="text"
                      defaultValue={editingStaff?.specialization || ''}
                      className="clinic-input"
                      placeholder="e.g., Cardiology, General Medicine"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Department *
                    </label>
                    <select
                      name="department"
                      required
                      defaultValue={editingStaff?.department || ''}
                      className="clinic-select"
                    >
                      <option value="">Select Department</option>
                      <option value="general">General Medicine</option>
                      <option value="cardiology">Cardiology</option>
                      <option value="orthopedics">Orthopedics</option>
                      <option value="dermatology">Dermatology</option>
                      <option value="pediatrics">Pediatrics</option>
                      <option value="gynecology">Gynecology</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Qualification *
                    </label>
                    <input
                      name="qualification"
                      type="text"
                      required
                      defaultValue={editingStaff?.qualification || ''}
                      className="clinic-input"
                      placeholder="e.g., MD, MBBS, High School Diploma"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Experience (Years) *
                    </label>
                    <input
                      name="experience"
                      type="number"
                      min="0"
                      required
                      defaultValue={editingStaff?.experience || ''}
                      className="clinic-input"
                      placeholder="5"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Join Date *
                    </label>
                    <input
                      name="joinDate"
                      type="date"
                      required
                      defaultValue={editingStaff?.joinDate ? new Date(editingStaff.joinDate).toISOString().split('T')[0] : ''}
                      className="clinic-input"
                    />
                  </div>
                </div>

                {/* Schedule */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Working Schedule
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map((day) => (
                      <div key={day}>
                        <label className="block text-sm text-gray-600 mb-1 capitalize">
                          {day}
                        </label>
                        <input
                          name={day}
                          type="text"
                          defaultValue={editingStaff?.schedule?.[day] || ''}
                          className="clinic-input"
                          placeholder="09:00-17:00 or Off"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-4 pt-4">
                  <button type="submit" className="clinic-button-primary flex-1">
                    {editingStaff ? 'Update Staff Member' : 'Add Staff Member'}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setShowForm(false); setEditingStaff(null) }}
                    className="clinic-button-secondary flex-1"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Staff
