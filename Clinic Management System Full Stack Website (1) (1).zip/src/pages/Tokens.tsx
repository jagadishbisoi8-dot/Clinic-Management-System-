
import React, { useState, useEffect } from 'react'
import { lumi } from '../lib/lumi'
import { useAuth } from '../hooks/useAuth'
import {Plus, Search, Clock, User, Calendar, CheckCircle, XCircle, AlertCircle, Stethoscope} from 'lucide-react'
import toast from 'react-hot-toast'
import { generateTokenNumber } from '../utils/tokenGenerator'

interface Token {
  _id: string
  tokenNumber: string
  patientId: string
  patientName: string
  date: string
  timeSlot: string
  department: string
  doctorId?: string
  priority: string
  status: string
  notes?: string
  createdAt: string
}

interface Patient {
  _id: string
  patientId: string
  name: string
  phone: string
}

interface Staff {
  _id: string
  staffId: string
  name: string
  role: string
  department: string
}

const Tokens: React.FC = () => {
  const { user } = useAuth()
  const [tokens, setTokens] = useState<Token[]>([])
  const [patients, setPatients] = useState<Patient[]>([])
  const [doctors, setDoctors] = useState<Staff[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0])

  useEffect(() => {
    fetchData()
  }, [selectedDate])

  const fetchData = async () => {
    try {
      setLoading(true)
      
      // Fetch tokens for selected date
      const dateStart = new Date(selectedDate + 'T00:00:00.000Z')
      const dateEnd = new Date(selectedDate + 'T23:59:59.999Z')
      
      const [tokensRes, patientsRes, staffRes] = await Promise.all([
        lumi.entities.tokens.list({
          filter: {
            date: {
              $gte: dateStart.toISOString(),
              $lte: dateEnd.toISOString()
            }
          },
          sort: { createdAt: -1 }
        }),
        lumi.entities.patients.list({ filter: { status: 'active' } }),
        lumi.entities.staff.list({ filter: { role: 'doctor', status: 'active' } })
      ])

      setTokens(tokensRes.list || [])
      setPatients(patientsRes.list || [])
      setDoctors(staffRes.list || [])
    } catch (error) {
      console.error('Failed to fetch data:', error)
      toast.error('Failed to load data')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    
    const selectedPatient = patients.find(p => p._id === formData.get('patientId'))
    if (!selectedPatient) {
      toast.error('Please select a patient')
      return
    }

    const tokenData = {
      tokenNumber: await generateTokenNumber(new Date(selectedDate)),
      patientId: selectedPatient._id,
      patientName: selectedPatient.name,
      date: new Date(selectedDate + 'T' + formData.get('timeSlot')).toISOString(),
      timeSlot: formData.get('timeSlot') as string,
      department: formData.get('department') as string,
      doctorId: formData.get('doctorId') as string,
      priority: formData.get('priority') as string,
      status: 'waiting',
      notes: formData.get('notes') as string,
      creator: user?.staffId || user?.userName || 'system',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    try {
      await lumi.entities.tokens.create(tokenData)
      toast.success('Token generated successfully')
      setShowForm(false)
      fetchData()
    } catch (error) {
      console.error('Failed to create token:', error)
      toast.error('Failed to generate token')
    }
  }

  const updateTokenStatus = async (tokenId: string, newStatus: string) => {
    try {
      await lumi.entities.tokens.update(tokenId, {
        status: newStatus,
        updatedAt: new Date().toISOString()
      })
      toast.success('Token status updated')
      fetchData()
    } catch (error) {
      console.error('Failed to update token status:', error)
      toast.error('Failed to update status')
    }
  }

  const filteredTokens = tokens.filter(token =>
    token.tokenNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    token.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    token.department.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'waiting': return <Clock className="w-4 h-4" />
      case 'in_progress': return <AlertCircle className="w-4 h-4" />
      case 'completed': return <CheckCircle className="w-4 h-4" />
      case 'cancelled': return <XCircle className="w-4 h-4" />
      default: return <Clock className="w-4 h-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'waiting': return 'text-yellow-600 bg-yellow-100'
      case 'in_progress': return 'text-blue-600 bg-blue-100'
      case 'completed': return 'text-green-600 bg-green-100'
      case 'cancelled': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'emergency': return 'text-red-600 bg-red-100'
      case 'urgent': return 'text-orange-600 bg-orange-100'
      case 'normal': return 'text-green-600 bg-green-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">
          {user?.role === 'doctor' ? 'My Appointments' : 'Token Management'}
        </h1>
        {user?.role === 'receptionist' && (
          <button
            onClick={() => setShowForm(true)}
            className="clinic-button-primary flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Generate Token</span>
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by token, patient name, or department..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="clinic-input pl-10"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Calendar className="w-5 h-5 text-gray-400" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="clinic-input"
          />
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Tokens', value: tokens.length, color: 'blue' },
          { label: 'Waiting', value: tokens.filter(t => t.status === 'waiting').length, color: 'yellow' },
          { label: 'In Progress', value: tokens.filter(t => t.status === 'in_progress').length, color: 'blue' },
          { label: 'Completed', value: tokens.filter(t => t.status === 'completed').length, color: 'green' }
        ].map((stat, index) => (
          <div key={index} className="clinic-card">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Tokens List */}
      <div className="space-y-4">
        {filteredTokens.map((token) => (
          <div key={token._id} className="clinic-card">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-sm">
                    {token.tokenNumber.split('-')[0].slice(-2)}
                  </span>
                </div>
                
                <div>
                  <h3 className="font-semibold text-gray-900">{token.patientName}</h3>
                  <p className="text-sm text-gray-600">{token.tokenNumber}</p>
                </div>
              </div>

              <div className="flex items-center space-x-6">
                <div className="text-center">
                  <p className="text-sm text-gray-500">Time</p>
                  <p className="font-medium">{token.timeSlot}</p>
                </div>
                
                <div className="text-center">
                  <p className="text-sm text-gray-500">Department</p>
                  <p className="font-medium capitalize">{token.department}</p>
                </div>
                
                <div className="text-center">
                  <p className="text-sm text-gray-500">Priority</p>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(token.priority)}`}>
                    {token.priority}
                  </span>
                </div>
                
                <div className="text-center">
                  <p className="text-sm text-gray-500">Status</p>
                  <span className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(token.status)}`}>
                    {getStatusIcon(token.status)}
                    <span>{token.status.replace('_', ' ')}</span>
                  </span>
                </div>

                {/* Action Buttons */}
                {user?.role === 'doctor' && token.status !== 'completed' && token.status !== 'cancelled' && (
                  <div className="flex space-x-2">
                    {token.status === 'waiting' && (
                      <button
                        onClick={() => updateTokenStatus(token._id, 'in_progress')}
                        className="clinic-button-primary text-xs px-3 py-1"
                      >
                        Start
                      </button>
                    )}
                    {token.status === 'in_progress' && (
                      <button
                        onClick={() => updateTokenStatus(token._id, 'completed')}
                        className="clinic-button-success text-xs px-3 py-1"
                      >
                        Complete
                      </button>
                    )}
                  </div>
                )}

                {user?.role === 'receptionist' && (
                  <div className="flex space-x-2">
                    {token.status === 'waiting' && (
                      <button
                        onClick={() => updateTokenStatus(token._id, 'cancelled')}
                        className="clinic-button-danger text-xs px-3 py-1"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>

            {token.notes && (
              <div className="mt-3 pt-3 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  <strong>Notes:</strong> {token.notes}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>

      {filteredTokens.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No tokens found for selected date</p>
        </div>
      )}

      {/* Token Generation Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-6">Generate New Token</h2>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Patient *
                  </label>
                  <select name="patientId" required className="clinic-select">
                    <option value="">Select Patient</option>
                    {patients.map((patient) => (
                      <option key={patient._id} value={patient._id}>
                        {patient.name} - {patient.patientId}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Time Slot *
                  </label>
                  <input
                    name="timeSlot"
                    type="time"
                    required
                    className="clinic-input"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Department *
                  </label>
                  <select name="department" required className="clinic-select">
                    <option value="">Select Department</option>
                    <option value="general">General Medicine</option>
                    <option value="cardiology">Cardiology</option>
                    <option value="orthopedics">Orthopedics</option>
                    <option value="dermatology">Dermatology</option>
                    <option value="pediatrics">Pediatrics</option>
                    <option value="gynecology">Gynecology</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Doctor
                  </label>
                  <select name="doctorId" className="clinic-select">
                    <option value="">Select Doctor</option>
                    {doctors.map((doctor) => (
                      <option key={doctor._id} value={doctor.staffId}>
                        {doctor.name} - {doctor.specialization}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Priority *
                  </label>
                  <select name="priority" required className="clinic-select">
                    <option value="normal">Normal</option>
                    <option value="urgent">Urgent</option>
                    <option value="emergency">Emergency</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Notes
                  </label>
                  <textarea
                    name="notes"
                    className="clinic-textarea"
                    placeholder="Additional notes..."
                    rows={3}
                  />
                </div>

                <div className="flex space-x-4 pt-4">
                  <button type="submit" className="clinic-button-primary flex-1">
                    Generate Token
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="clinic-button-secondary flex-1"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Tokens
