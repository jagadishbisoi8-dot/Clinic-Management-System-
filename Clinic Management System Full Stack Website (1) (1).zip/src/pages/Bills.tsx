
import React, { useState, useEffect } from 'react'
import { lumi } from '../lib/lumi'
import { useAuth } from '../hooks/useAuth'
import {Plus, Search, CreditCard, User, Calendar, DollarSign, FileText, Edit, Trash2, CheckCircle, Clock} from 'lucide-react'
import toast from 'react-hot-toast'
import { generateBillId, calculateBillTotal } from '../utils/tokenGenerator'

interface Bill {
  _id: string
  billId: string
  patientId: string
  patientName: string
  tokenId?: string
  prescriptionId?: string
  items: BillItem[]
  subtotal: number
  tax: number
  discount: number
  totalAmount: number
  paymentMethod?: string
  paymentStatus: string
  paidAmount: number
  status: string
  notes?: string
  createdAt: string
}

interface BillItem {
  description: string
  quantity: number
  unitPrice: number
  amount: number
}

interface Patient {
  _id: string
  patientId: string
  name: string
}

interface Token {
  _id: string
  tokenNumber: string
  patientId: string
  patientName: string
  status: string
}

const Bills: React.FC = () => {
  const { user } = useAuth()
  const [bills, setBills] = useState<Bill[]>([])
  const [patients, setPatients] = useState<Patient[]>([])
  const [tokens, setTokens] = useState<Token[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editingBill, setEditingBill] = useState<Bill | null>(null)
  const [billItems, setBillItems] = useState<BillItem[]>([
    { description: '', quantity: 1, unitPrice: 0, amount: 0 }
  ])

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      
      const [billsRes, patientsRes, tokensRes] = await Promise.all([
        lumi.entities.bills.list({ sort: { createdAt: -1 } }),
        lumi.entities.patients.list({ filter: { status: 'active' } }),
        lumi.entities.tokens.list({ filter: { status: 'completed' } })
      ])

      setBills(billsRes.list || [])
      setPatients(patientsRes.list || [])
      setTokens(tokensRes.list || [])
    } catch (error) {
      console.error('Failed to fetch data:', error)
      toast.error('Failed to load data')
    } finally {
      setLoading(false)
    }
  }

  const addBillItem = () => {
    setBillItems([...billItems, { description: '', quantity: 1, unitPrice: 0, amount: 0 }])
  }

  const removeBillItem = (index: number) => {
    if (billItems.length > 1) {
      setBillItems(billItems.filter((_, i) => i !== index))
    }
  }

  const updateBillItem = (index: number, field: keyof BillItem, value: string | number) => {
    const updatedItems = [...billItems]
    updatedItems[index] = { ...updatedItems[index], [field]: value }
    
    // Calculate amount for this item
    if (field === 'quantity' || field === 'unitPrice') {
      updatedItems[index].amount = updatedItems[index].quantity * updatedItems[index].unitPrice
    }
    
    setBillItems(updatedItems)
  }

  const calculateTotals = () => {
    const subtotal = billItems.reduce((sum, item) => sum + item.amount, 0)
    return { subtotal }
  }

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    
    const selectedPatient = patients.find(p => p._id === formData.get('patientId'))
    if (!selectedPatient) {
      toast.error('Please select a patient')
      return
    }

    // Filter out empty items
    const validItems = billItems.filter(item => item.description.trim() !== '' && item.unitPrice > 0)
    if (validItems.length === 0) {
      toast.error('Please add at least one bill item')
      return
    }

    const tax = parseFloat(formData.get('tax') as string) || 0
    const discount = parseFloat(formData.get('discount') as string) || 0
    const subtotal = validItems.reduce((sum, item) => sum + item.amount, 0)
    const totalAmount = subtotal + tax - discount

    const billData = {
      billId: editingBill?.billId || generateBillId(),
      patientId: selectedPatient._id,
      patientName: selectedPatient.name,
      tokenId: formData.get('tokenId') as string || undefined,
      prescriptionId: formData.get('prescriptionId') as string || undefined,
      items: validItems,
      subtotal,
      tax,
      discount,
      totalAmount,
      paymentMethod: formData.get('paymentMethod') as string || undefined,
      paymentStatus: 'pending',
      paidAmount: 0,
      status: 'finalized',
      notes: formData.get('notes') as string,
      creator: user?.staffId || user?.userName || 'system',
      createdAt: editingBill?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    try {
      if (editingBill) {
        await lumi.entities.bills.update(editingBill._id, billData)
        toast.success('Bill updated successfully')
      } else {
        await lumi.entities.bills.create(billData)
        toast.success('Bill created successfully')
      }
      
      setShowForm(false)
      setEditingBill(null)
      resetForm()
      fetchData()
    } catch (error) {
      console.error('Failed to save bill:', error)
      toast.error('Failed to save bill')
    }
  }

  const resetForm = () => {
    setBillItems([{ description: '', quantity: 1, unitPrice: 0, amount: 0 }])
  }

  const handleEdit = (bill: Bill) => {
    setEditingBill(bill)
    setBillItems(bill.items.length > 0 ? bill.items : [{ description: '', quantity: 1, unitPrice: 0, amount: 0 }])
    setShowForm(true)
  }

  const handleDelete = async (billId: string, patientName: string) => {
    if (!confirm(`Are you sure you want to delete bill for ${patientName}?`)) return

    try {
      await lumi.entities.bills.delete(billId)
      toast.success('Bill deleted successfully')
      fetchData()
    } catch (error) {
      console.error('Failed to delete bill:', error)
      toast.error('Failed to delete bill')
    }
  }

  const markAsPaid = async (billId: string, totalAmount: number) => {
    try {
      await lumi.entities.bills.update(billId, {
        paymentStatus: 'paid',
        paidAmount: totalAmount,
        status: 'paid',
        updatedAt: new Date().toISOString()
      })
      toast.success('Bill marked as paid')
      fetchData()
    } catch (error) {
      console.error('Failed to update payment status:', error)
      toast.error('Failed to update payment status')
    }
  }

  const filteredBills = bills.filter(bill =>
    bill.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bill.billId.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'text-green-600 bg-green-100'
      case 'pending': return 'text-yellow-600 bg-yellow-100'
      case 'partial': return 'text-orange-600 bg-orange-100'
      case 'cancelled': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Billing Management</h1>
        <button
          onClick={() => { setEditingBill(null); resetForm(); setShowForm(true) }}
          className="clinic-button-primary flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Create Bill</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Search by patient name or bill ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="clinic-input pl-10"
        />
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { 
            label: 'Total Bills', 
            value: bills.length, 
            color: 'blue',
            icon: FileText
          },
          { 
            label: 'Pending Payment', 
            value: bills.filter(b => b.paymentStatus === 'pending').length, 
            color: 'yellow',
            icon: Clock
          },
          { 
            label: 'Paid Bills', 
            value: bills.filter(b => b.paymentStatus === 'paid').length, 
            color: 'green',
            icon: CheckCircle
          },
          { 
            label: 'Total Revenue', 
            value: `$${bills.filter(b => b.paymentStatus === 'paid').reduce((sum, b) => sum + b.totalAmount, 0).toFixed(2)}`, 
            color: 'green',
            icon: DollarSign
          }
        ].map((stat, index) => {
          const Icon = stat.icon
          return (
            <div key={index} className="clinic-card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${stat.color}-100`}>
                  <Icon className={`w-6 h-6 text-${stat.color}-600`} />
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Bills List */}
      <div className="space-y-4">
        {filteredBills.map((bill) => (
          <div key={bill._id} className="clinic-card">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4 flex-1">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-purple-600" />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="font-semibold text-gray-900">{bill.patientName}</h3>
                    <span className="text-sm text-gray-500">{bill.billId}</span>
                    <span className={`status-${bill.status}`}>
                      {bill.status}
                    </span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPaymentStatusColor(bill.paymentStatus)}`}>
                      {bill.paymentStatus}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">
                        <strong>Date:</strong> {new Date(bill.createdAt).toLocaleDateString()}
                      </p>
                      <p className="text-sm text-gray-600">
                        <strong>Items:</strong> {bill.items.length}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">
                        <strong>Subtotal:</strong> ${bill.subtotal.toFixed(2)}
                      </p>
                      <p className="text-sm text-gray-600">
                        <strong>Tax:</strong> ${bill.tax.toFixed(2)}
                      </p>
                    </div>
                    <div>
                      <p className="text-lg font-bold text-gray-900">
                        Total: ${bill.totalAmount.toFixed(2)}
                      </p>
                      {bill.paymentStatus === 'paid' && (
                        <p className="text-sm text-green-600">
                          Paid: ${bill.paidAmount.toFixed(2)}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Bill Items */}
                  <div className="bg-gray-50 p-3 rounded-lg mb-3">
                    <h4 className="font-medium text-gray-900 mb-2">Items:</h4>
                    <div className="space-y-1">
                      {bill.items.map((item, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span>{item.description} (x{item.quantity})</span>
                          <span>${item.amount.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {bill.notes && (
                    <p className="text-sm text-gray-600 bg-blue-50 p-2 rounded">
                      <strong>Notes:</strong> {bill.notes}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-col space-y-2">
                {bill.paymentStatus === 'pending' && (
                  <button
                    onClick={() => markAsPaid(bill._id, bill.totalAmount)}
                    className="clinic-button-success text-sm px-3 py-1"
                  >
                    Mark Paid
                  </button>
                )}
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleEdit(bill)}
                    className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(bill._id, bill.patientName)}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredBills.length === 0 && (
        <div className="text-center py-12">
          <CreditCard className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No bills found</p>
        </div>
      )}

      {/* Bill Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-6">
                {editingBill ? 'Edit Bill' : 'Create New Bill'}
              </h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Patient *
                    </label>
                    <select 
                      name="patientId" 
                      required 
                      defaultValue={editingBill?.patientId || ''}
                      className="clinic-select"
                    >
                      <option value="">Select Patient</option>
                      {patients.map((patient) => (
                        <option key={patient._id} value={patient._id}>
                          {patient.name} - {patient.patientId}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Associated Token (Optional)
                    </label>
                    <select 
                      name="tokenId" 
                      defaultValue={editingBill?.tokenId || ''}
                      className="clinic-select"
                    >
                      <option value="">No associated token</option>
                      {tokens.map((token) => (
                        <option key={token._id} value={token._id}>
                          {token.tokenNumber} - {token.patientName}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Bill Items */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="block text-sm font-medium text-gray-700">
                      Bill Items *
                    </label>
                    <button
                      type="button"
                      onClick={addBillItem}
                      className="clinic-button-secondary text-sm px-3 py-1"
                    >
                      Add Item
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    {billItems.map((item, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-medium text-gray-900">Item {index + 1}</h4>
                          {billItems.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeBillItem(index)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                          <div className="md:col-span-2">
                            <label className="block text-sm text-gray-600 mb-1">Description</label>
                            <input
                              type="text"
                              value={item.description}
                              onChange={(e) => updateBillItem(index, 'description', e.target.value)}
                              className="clinic-input"
                              placeholder="e.g., Consultation fee"
                            />
                          </div>
                          <div>
                            <label className="block text-sm text-gray-600 mb-1">Quantity</label>
                            <input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) => updateBillItem(index, 'quantity', parseInt(e.target.value) || 1)}
                              className="clinic-input"
                            />
                          </div>
                          <div>
                            <label className="block text-sm text-gray-600 mb-1">Unit Price ($)</label>
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.unitPrice}
                              onChange={(e) => updateBillItem(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                              className="clinic-input"
                            />
                          </div>
                        </div>
                        <div className="mt-3 text-right">
                          <span className="text-sm text-gray-600">Amount: </span>
                          <span className="font-medium">${item.amount.toFixed(2)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Totals */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Tax ($)
                      </label>
                      <input
                        name="tax"
                        type="number"
                        min="0"
                        step="0.01"
                        defaultValue={editingBill?.tax || 0}
                        className="clinic-input"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Discount ($)
                      </label>
                      <input
                        name="discount"
                        type="number"
                        min="0"
                        step="0.01"
                        defaultValue={editingBill?.discount || 0}
                        className="clinic-input"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Subtotal
                      </label>
                      <div className="clinic-input bg-gray-100">
                        ${calculateTotals().subtotal.toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Payment Method
                    </label>
                    <select 
                      name="paymentMethod" 
                      defaultValue={editingBill?.paymentMethod || ''}
                      className="clinic-select"
                    >
                      <option value="">Select Payment Method</option>
                      <option value="cash">Cash</option>
                      <option value="card">Credit/Debit Card</option>
                      <option value="insurance">Insurance</option>
                      <option value="online">Online Payment</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Notes
                    </label>
                    <input
                      name="notes"
                      type="text"
                      defaultValue={editingBill?.notes || ''}
                      className="clinic-input"
                      placeholder="Additional notes..."
                    />
                  </div>
                </div>

                <div className="flex space-x-4 pt-4">
                  <button type="submit" className="clinic-button-primary flex-1">
                    {editingBill ? 'Update Bill' : 'Create Bill'}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setShowForm(false); setEditingBill(null); resetForm() }}
                    className="clinic-button-secondary flex-1"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Bills
